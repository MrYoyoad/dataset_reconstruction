PLOT NUMBERS — LoRA privacy-leakage figures
=============================================
All numeric data behind the figures. Provenance: WEXAC job 581629
(mnist/fashion, N=10, k=8, Nk=80, T=1000, lr=0.5, S=320(+640 at r=8/32),
gelu, tangent=qr, seed=42, float64). Source of truth: mc_rank_sweep_581629.out.

FILES
-----
rank_sweep_numbers.csv   -> the rank-sweep headline / eps / iso plots.
  One row per (dataset, num_classes, rank, S). Columns:
    r_J            = hard rank of col(J) (=80 => full; leakage master gate)
    iso_ratio      = tr(Sigma_J)/(mu*r_J), the noise-coupling into col(J)
    qeff_colJ_epsE = q_eff|col(J) at threshold eps=E  (THE leakage count, "at least X directions")
    raw_eff_rank   = eff_rank(J) (spectral-shape diagnostic; NOT leakage)
    max_bce, memorized = convergence (from the rigor pass in the log)
  The headline plot = qeff_colJ_eps1.0, binary(nc2) vs 10-class(nc10), converged rows only.
  NOTE: mnist nc10 r=2 and r=4 are UNDERFIT (memorized=False) -> convergence-confounded,
        excluded from the money panel. fashion nc10 r=8 was FD-chaotic (bounded out, no row).

spectrum_r8_numbers.csv  -> the sigma(J_SNR) spectrum plot at r=8 (both bases, S=320).
  q_eff = count of sigma_snr values above the eps threshold.

reconstruction_numbers.csv -> the SSIM / reconstruction numbers (OPEN LIMITATION).
  raw_ssim vs mean_image_baseline is the like-for-like comparison.
  FINDING: DECODED (adapter-only) beats the raw mean-image baseline in 0 of 40 arms.
  ssim_norm is a mean/std-matched (inflated) metric; the "~0.57-0.61" quoted elsewhere is
  ssim_norm and was never compared to the baseline. Pixel reconstruction does NOT beat a
  trivial baseline and is an open limitation, not a result.

mc_rank_sweep_581629.out -> the raw WEXAC log (every printed number, source of truth).
